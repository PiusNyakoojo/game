# multiplayer_template
A template for 3d, realtime, multiplayer capability with three.js, node.js, express.js and socket.io
